# Sudo Find PrivEsc (Easy)

- User: `student` / `student`
- Vulnerability: `sudo` allows `/usr/bin/find` with NOPASSWD
- Goal: read `FLAG{sudo_find_priv_esc}` from `/root/flag.txt`
